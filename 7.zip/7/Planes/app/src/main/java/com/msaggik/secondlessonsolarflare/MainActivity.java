package com.msaggik.secondlessonsolarflare;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class  MainActivity extends AppCompatActivity {

    // поля
    private float[][] plane = {{210, 850, 3.7f}, {189, 900, 2.8f}, {8, 250, 14, 100}}; // вместимость 210 человек, максимальная скорость 850 км/час,расход топлива 3,7 тонны в час
    private int samolet = 0;
private TextView samolet7;
    private TextView plane1but, plane2but, plane3but, samolet76; // окно вывода на экран смартфона решения задачи
    private EditText edit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edit = findViewById(R.id.edit);
        plane1but = findViewById(R.id.samolet1);
        plane2but = findViewById(R.id.samolet2);
        plane3but = findViewById(R.id.samolet3);
        samolet76 = findViewById(R.id.samolet76);
        samolet7 = findViewById(R.id.samolet7);
        edit.setText("");
        plane1but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                plane1but.setVisibility(View.GONE);
                plane2but.setVisibility(View.GONE);
                plane3but.setVisibility(View.GONE);
                edit.setVisibility(View.VISIBLE);
                samolet7.setVisibility(View.VISIBLE);
                samolet = 1;
            }
        });
        plane2but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                plane1but.setVisibility(View.GONE);
                plane2but.setVisibility(View.GONE);
                plane3but.setVisibility(View.GONE);
                edit.setVisibility(View.VISIBLE);
                samolet7.setVisibility(View.VISIBLE);
                samolet = 2;
            }
        });
        plane3but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                plane1but.setVisibility(View.GONE);
                plane2but.setVisibility(View.GONE);
                plane3but.setVisibility(View.GONE);
                edit.setVisibility(View.VISIBLE);
                samolet7.setVisibility(View.VISIBLE);
                samolet = 3;
            }
        });
        samolet7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edit.getText().length() == 0){
                    i("Введите число");
                    System.out.println("не введено число.");
                }
                if(isNumeric(String.valueOf(edit.getText()))){
                    float time = Float.valueOf(String.valueOf(edit.getText())) / Float.valueOf((int) plane[samolet - 1][1]);
                    int toplivo = Integer.valueOf((int) plane[samolet - 1][2] * 1000);
                    float toplivo2 = toplivo * time;
                    samolet76.setVisibility(View.VISIBLE);
                    samolet76.setText("Ответ:\nВремя: " + String.valueOf(time) + " часа(ов)\nПонадобится топлива: " + toplivo2 + " килограмм");
                }
            }
        });
    }

    // МОДУЛЬ 1
    // метод конвертирования времени задержки из минут в секунды (задержка в минутах)
    private int delaySecond(int delayMinute) {
        return delayMinute * 60;
    }
    private void i(String str){
        Toast.makeText(this, str, Toast.LENGTH_SHORT);
    }
    private static boolean isNumeric(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } catch(NumberFormatException e){
            return false;
        }
    }
    // МОДУЛЬ 2
    // метод определения времени обработки компьютером данных с одной планеты в секундах (скорость компьютера, размер данных)
    private int volumeTime(int coreFrequency, int volumeData) {
        return volumeData / coreFrequency;
    }

    // МОДУЛЬ 3 (использующий МОДУЛИ 1-2)
    // метод вычисления времени обработки компьютером приходящей информации в секундах (массив задержек, массив объёмов данных, скорость компьютера)
    private int coreTime(int[] delayMinute, int[] volumeData, int frequency) {

        int[] delay = new int[delayMinute.length]; // создание пустого массива для задержек времени в секундах
        for (int i = 0; i < delay.length; i++) { // инициализация данного массива этого массива конвертированными данными (из минут в секунды)
            delay[i] = delaySecond(delayMinute[i]); // конвертация каждой ячейки массива из минут в секунды
        }

        int[] volume = new int[volumeData.length]; // создание пустого массива для времени обработки компьютером данных от спутника (в секундах)
        for (int i = 0; i < volume.length; i++) { // инициализация данного массива
            volume[i] = volumeTime(frequency, volumeData[i]); // определение времени обработки компьютером данных от одного спутника
        }

        int count = 0; // счётчик времени работы ядра компьютера
        int countOperation = 0; // счётчик количества подданных на ядро операций в секунду (например, обработка информации от двух спутников)
        boolean run = true; // флаг хода времени обработки данных со спутников

        while (run) { // бесконечный цикл работы ядра компьютера до прерывания

            count++; // повышение отсчёта времени на одну секунду
            run = false; // временное ограничение цикла while одним циклом

            for (int i = 0; i < delay.length; i++) { // с течением времени уменьшение задержки прихода информации со спутников
                if (delay[i] > 0) { // если от одного спутника сигнал ещё не дошёл, то
                    delay[i]--; // уменьшаем задержку на 1 секунду
                    run = true; // снятие ограничения на цикл while (так как в следующем цикле есть что обрабатывать)
                } else { // иначе обрабатываем данные со спутника
                    if (volume[i] > 0) { // если есть что обрабатывать, то
                        volume[i]--; // обрабатываем
                        countOperation++; // и повышаем счётчик занятости ядра компьютера
                        if (countOperation > 1) { // если в этот момент ядро уже было занято, то
                            count++; // прибавляем секунду к времени обработки ядром компьютера
                            countOperation--; // освобождаем ядро
                        }
                        run = true; // снятие ограничения на цикл while (так как в следующем цикле есть что обрабатывать)
                    } else { // иначе
                        // данные с данного спутника обработаны
                    }
                }
            }
        }

        return count; // возврат времени обработки данных от спутников (в секундах)
    }
}